const express = require('express');
var path = require('path');
var morgan = require('morgan');
var cors = require('cors');
var app = express();
const port = 3000;






//MIDDLEWARES
app.use(morgan('dev'));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/jquery', express.static(path.join(__dirname, 'node_modules/jquery/dist')));
app.use(express.json());
app.use(express.urlencoded({ extended: false }))

app.use(function(req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Authorization');
    next();
});

//export LD_LIBRARY_PATH=/home/eljuanjoramos/Documentos/instantclient_19_8/


//ROUTES
var category = require('./routes/category.route');
app.use("/", category);



  
app.listen(port, function() {
	console.log("The server is running at: " + port);
});